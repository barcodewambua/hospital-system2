# Healthcare Facility Website

A modern, responsive healthcare facility website built with Flask, HTML, and CSS. This website provides a user-friendly interface for patients to learn about healthcare services, meet the medical team, and schedule appointments.

## Features

- 🏥 Modern and responsive design
- 📱 Mobile-first approach
- 🔍 Service showcase with detailed information
- 👨‍⚕️ Medical team profiles
- 📅 Appointment booking system
- 📝 Contact form with location map
- 🌓 Professional theme with clean UI

## Prerequisites

Before you begin, ensure you have the following installed:
- Python 3.11 or higher
- pip (Python package manager)

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
```

2. Navigate to the project directory:
```bash
cd healthcare-facility
```

3. Install required Python packages:
```bash
pip install flask flask-sqlalchemy python-dotenv werkzeug
```

## Running the Application

1. Start the Flask development server:
```bash
python app.py
```

2. Open your browser and visit:
```
http://localhost:5000
```

The application will run on port 5000 and includes both frontend and backend functionality.

## Project Structure

```
├── app.py                  # Main Flask application file
├── static/                 # Static files
│   ├── css/               # CSS stylesheets
│   │   └── style.css      # Main stylesheet
│   └── images/            # Image assets
├── templates/             # HTML templates
│   ├── base.html         # Base template
│   ├── home.html         # Home page
│   ├── services.html     # Services page
│   ├── about.html        # About page
│   ├── contact.html      # Contact page
│   └── appointments.html # Appointments page
```

## Technologies Used

- **Backend**:
  - Flask (Python web framework)
  - SQLAlchemy (Database ORM)
  - Werkzeug (WSGI utility library)

- **Frontend**:
  - HTML5
  - CSS3
  - JavaScript
  - Font Awesome (for icons)

## Available Pages

- **Home** (`/`): Landing page with services overview and testimonials
- **Services** (`/services`): Detailed list of medical services
- **About** (`/about`): Facility information and medical team
- **Contact** (`/contact`): Contact form and location details
- **Appointments** (`/appointments`): Appointment booking system

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.