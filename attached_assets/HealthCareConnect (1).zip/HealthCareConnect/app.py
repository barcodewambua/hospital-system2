from flask import Flask, render_template, request, jsonify
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev')

# Custom error handling
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# Context processor for adding date to all templates
@app.context_processor
def inject_now():
    return {'now': datetime.utcnow()}

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        try:
            data = request.form
            # Here you would typically save to database and send email
            # For now, just return success
            return jsonify({
                "status": "success",
                "message": "Message sent successfully"
            })
        except Exception as e:
            return jsonify({
                "status": "error",
                "message": str(e)
            }), 400
    return render_template('contact.html')

@app.route('/appointments', methods=['GET', 'POST'])
def appointments():
    if request.method == 'POST':
        try:
            data = request.form
            # Here you would typically save to database and send confirmation
            # For now, just return success
            return jsonify({
                "status": "success",
                "message": "Appointment scheduled successfully"
            })
        except Exception as e:
            return jsonify({
                "status": "error",
                "message": str(e)
            }), 400
    return render_template('appointments.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)