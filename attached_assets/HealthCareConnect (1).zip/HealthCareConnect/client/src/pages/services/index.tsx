import { Stethoscope, Heart, Brain, Baby, Bone, Eye, 
  Microscope, Pill, Activity } from "lucide-react";
import ServiceCard from "@/components/services/ServiceCard";

const services = [
  {
    icon: Stethoscope,
    title: "General Medicine",
    description: "Comprehensive medical care for patients of all ages",
    details: [
      "Regular health check-ups and screenings",
      "Diagnosis and treatment of common illnesses",
      "Preventive care and wellness advice",
      "Chronic disease management"
    ]
  },
  {
    icon: Heart,
    title: "Cardiology",
    description: "Expert care for heart and cardiovascular conditions",
    details: [
      "Heart disease diagnosis and treatment",
      "ECG and stress testing",
      "Blood pressure management",
      "Cardiac rehabilitation programs"
    ]
  },
  {
    icon: Brain,
    title: "Neurology",
    description: "Specialized treatment for neurological disorders",
    details: [
      "Diagnosis of neurological conditions",
      "Treatment of headaches and migraines",
      "Movement disorder management",
      "Cognitive function assessment"
    ]
  },
  {
    icon: Baby,
    title: "Pediatrics",
    description: "Dedicated healthcare for children and adolescents",
    details: [
      "Well-child visits and vaccinations",
      "Growth and development monitoring",
      "Pediatric illness treatment",
      "Behavioral health support"
    ]
  },
  {
    icon: Bone,
    title: "Orthopedics",
    description: "Treatment for bone, joint, and muscle conditions",
    details: [
      "Joint pain and injury treatment",
      "Sports medicine services",
      "Physical therapy programs",
      "Orthopedic surgery consultation"
    ]
  },
  {
    icon: Eye,
    title: "Ophthalmology",
    description: "Comprehensive eye care and vision services",
    details: [
      "Vision testing and correction",
      "Eye disease treatment",
      "Cataract evaluation",
      "Pediatric eye care"
    ]
  },
  {
    icon: Microscope,
    title: "Laboratory Services",
    description: "Advanced diagnostic testing and analysis",
    details: [
      "Blood work and analysis",
      "Diagnostic testing",
      "Rapid test results",
      "Professional lab interpretation"
    ]
  },
  {
    icon: Pill,
    title: "Emergency Care",
    description: "24/7 emergency medical services",
    details: [
      "Immediate medical attention",
      "Trauma care",
      "Emergency procedures",
      "Critical care services"
    ]
  },
  {
    icon: Activity,
    title: "Preventive Care",
    description: "Proactive health maintenance and disease prevention",
    details: [
      "Health risk assessments",
      "Immunizations",
      "Lifestyle counseling",
      "Preventive screenings"
    ]
  }
];

export default function Services() {
  return (
    <div className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our Services</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We offer comprehensive healthcare services using state-of-the-art 
            medical technology and experienced healthcare professionals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              details={service.details}
            />
          ))}
        </div>
      </div>
    </div>
  );
}