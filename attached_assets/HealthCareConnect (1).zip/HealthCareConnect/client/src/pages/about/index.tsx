import { Card, CardContent } from "@/components/ui/card";
import { Award, Heart, UserCheck } from "lucide-react";

const doctors = [
  {
    name: "Dr. Sarah Johnson",
    specialty: "Cardiology",
    image: "https://images.unsplash.com/photo-1612276529731-4b21494e6d71",
    credentials: "MD, FACC"
  },
  {
    name: "Dr. Michael Chen",
    specialty: "Neurology",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d",
    credentials: "MD, PhD"
  },
  {
    name: "Dr. Emily Davis",
    specialty: "Pediatrics",
    image: "https://images.unsplash.com/photo-1614579093335-b6ab37ddaace",
    credentials: "MD, FAAP"
  },
  {
    name: "Dr. James Wilson",
    specialty: "Orthopedics",
    image: "https://images.unsplash.com/photo-1612276529418-52e6ad86ee1d",
    credentials: "MD, FAAOS"
  },
  {
    name: "Dr. Lisa Martinez",
    specialty: "Ophthalmology",
    image: "https://images.unsplash.com/photo-1612531385446-f7e6d131e1d0",
    credentials: "MD, FAAO"
  },
  {
    name: "Dr. David Thompson",
    specialty: "General Medicine",
    image: "https://images.unsplash.com/photo-1524499982521-1ffd58dd89ea",
    credentials: "MD, MPH"
  }
];

const values = [
  {
    icon: Heart,
    title: "Patient-Centered Care",
    description: "We put our patients first, providing compassionate and personalized healthcare services."
  },
  {
    icon: Award,
    title: "Excellence",
    description: "We strive for excellence in all aspects of medical care and patient service."
  },
  {
    icon: UserCheck,
    title: "Trust & Integrity",
    description: "We maintain the highest standards of professional ethics and personal integrity."
  }
];

export default function About() {
  return (
    <div className="py-16">
      <div className="container">
        {/* Mission & Vision */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-4">About Us</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            Providing exceptional healthcare services with a commitment to improving 
            the health and well-being of our community.
          </p>
        </div>

        {/* Core Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {values.map((value, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="mb-4 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <value.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Our Team */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Our Medical Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {doctors.map((doctor, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="aspect-square mb-4 overflow-hidden rounded-lg">
                    <img
                      src={doctor.image}
                      alt={doctor.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold">{doctor.name}</h3>
                  <p className="text-sm text-muted-foreground mb-1">{doctor.specialty}</p>
                  <p className="text-sm text-muted-foreground">{doctor.credentials}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Facility */}
        <div>
          <h2 className="text-3xl font-bold text-center mb-8">Our Facility</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="aspect-video rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1504813184591-01572f98c85f"
                alt="Modern medical facility"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-video rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1519494080410-f9aa76cb4283"
                alt="Medical equipment"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-video rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1514416432279-50fac261c7dd"
                alt="Treatment room"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
