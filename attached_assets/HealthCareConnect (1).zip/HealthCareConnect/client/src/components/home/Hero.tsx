import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Hero() {
  return (
    <div className="relative py-20 md:py-28 overflow-hidden">
      <div className="container relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6 text-white">
            Expert Healthcare Services For Your Well-being
          </h1>
          <p className="text-lg text-white/90 mb-8">
            Experience exceptional medical care with our team of dedicated healthcare professionals. 
            Your health and comfort are our top priorities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" variant="default" className="bg-white text-primary hover:bg-white/90" asChild>
              <Link href="/appointments">Book an Appointment</Link>
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10" asChild>
              <Link href="/services">Our Services</Link>
            </Button>
          </div>
        </div>
      </div>
      <div className="absolute inset-0 -z-10">
        <img 
          src="https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?auto=format&fit=crop&q=80"
          alt="Medical facility"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-primary/80" />
      </div>
    </div>
  );
}