import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { LucideIcon } from "lucide-react";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  details: string[];
}

export default function ServiceCard({ icon: Icon, title, description, details }: ServiceCardProps) {
  return (
    <Card id={title.toLowerCase()} className="scroll-mt-20">
      <CardHeader>
        <div className="mb-4 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-6 h-6 text-primary" />
        </div>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="list-disc list-inside space-y-2 mb-6 text-sm text-muted-foreground">
          {details.map((detail, index) => (
            <li key={index}>{detail}</li>
          ))}
        </ul>
        <Button asChild>
          <Link href="/appointments">Book Appointment</Link>
        </Button>
      </CardContent>
    </Card>
  );
}
